module MyProject where

run :: IO ()
run = putStrLn "This project is not yet implemented"
