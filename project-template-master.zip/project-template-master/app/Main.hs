module Main where

import MyProject

main :: IO ()
main = run
